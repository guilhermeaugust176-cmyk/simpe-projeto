const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const lsGet=k=>{try{return localStorage.getItem(k)}catch(e){return null}},lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
document.documentElement.dataset.theme=lsGet('simpe-theme')||'dark';
document.addEventListener('DOMContentLoaded',()=>{if(!document.querySelector('link[rel~=icon]')){const l=document.createElement('link');l.rel='icon';l.type='image/png';l.href='img/favicon.png';document.head.append(l)}});
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const br=d=>d?String(d).split('-').reverse().join('/'):'';
const num=(v,d=1)=>typeof v==='number'?v.toFixed(d).replace('.',','):'—';
/* api(m,u,b,ms): timeout de 8 s via AbortController. Erros de rede/timeout acendem a faixa #net e carregam e.rede=true. */
async function api(m,u,b,ms=8000){
  const ac=new AbortController(),t=setTimeout(()=>ac.abort(),ms),t0=performance.now();let r,j=null;
  try{r=await fetch(u,{method:m,cache:'no-store',signal:ac.signal,headers:b?{'Content-Type':'application/json'}:{},body:b?JSON.stringify(b):undefined});lat(Math.round(performance.now()-t0));
    try{j=await r.json()}catch(e){}
    if(ac.signal.aborted)throw new DOMException('timeout','AbortError')}
  catch(e){lat(null);net(false);const x=new Error(e&&e.name==='AbortError'?'Sem conexão com o servidor (sem resposta em '+ms/1000+' s)':'Sem conexão com o servidor');x.rede=true;throw x}
  finally{clearTimeout(t)}
  net(true);
  if(r.status===401&&!/login|cadastro/.test(location.pathname)){const era=lsGet('simpe-sess');lsSet('simpe-sess','');location.href='login.html'+(era?'?expirou=1':'');throw new Error('Sessão expirada')}
  if(!r.ok)throw new Error((j&&j.erro)||(r.status>=500?'Erro interno do servidor ('+r.status+'). Tente novamente.':'Erro '+r.status));
  return j}
/* toast(msg) neutro · toast(msg,'ok') sucesso · toast(msg,'er') erro (fica mais tempo). Toasts empilham (máx. 4); mensagem idêntica só renova o tempo. */
function toast(m,tipo){let c=$('#toasts');if(!c){c=document.createElement('div');c.id='toasts';document.body.append(c)}
  const old=[...c.children].find(x=>x.textContent===m&&x.className==='tst '+(tipo||'').trim());
  const t=old||document.createElement('div');
  if(!old){t.className='tst '+(tipo||'');t.setAttribute('role',tipo==='er'?'alert':'status');t.textContent=m;t.onclick=()=>{clearTimeout(t._t);t.remove()};c.append(t);while(c.children.length>4)c.firstChild.remove()}
  clearTimeout(t._t);t._t=setTimeout(()=>t.remove(),tipo==='er'?6000:2600)}
/* Faixa fixa "Sem conexão com o servidor": api() liga ao falhar e desliga na primeira resposta */
function net(ok){let n=$('#net');if(ok){if(n)n.hidden=true;return}
  if(!n){n=document.createElement('div');n.id='net';n.setAttribute('role','alert');n.textContent='Sem conexão com o servidor. Verifique a rede ou o servidor do SIMPE.';document.body.append(n)}n.hidden=false}
/* Latência medida pela api(): tempo até a resposta chegar. lat(ms) registra · lat(null) = sem resposta.
   O rodapé de status (#lat) mostra a última medição (#sb-lat) e a média das últimas 10 no tooltip. */
const LATS=[];let LATF=false;
function lat(ms){if(ms==null)LATF=true;else{LATF=false;LATS.push(ms);if(LATS.length>10)LATS.shift()}latRender()}
function latRender(){const e=$('#sb-lat');if(!e)return;
  if(LATF){e.className='sb-i er';e.textContent='Latência da API: sem resposta';e.title='O servidor não respondeu à última requisição.';return}
  if(!LATS.length){e.className='sb-i';e.textContent='Latência da API: medindo…';e.title='';return}
  const u=LATS[LATS.length-1],m=Math.round(LATS.reduce((a,x)=>a+x,0)/LATS.length);
  e.className='sb-i '+(m>3000?'er':m>800?'wa':'');
  e.innerHTML='Latência da API: <b>'+u+' ms</b><span class="sb-d"> · média '+m+' ms</span>';
  e.title='Última resposta: '+u+' ms · média das últimas '+LATS.length+': '+m+' ms. Tempo medido pelo seu navegador até o servidor responder.'}
/* Módulo de monitoramento (ESP32): /api/status → hardware.conectado (o ESP32 consultou o servidor há menos de 5 s). */
let MODS='',MODT='',MODB=false;
function modRender(){const e=$('#sb-mod');if(!e)return;
  const t={ok:['ok','Módulo de monitoramento: conectado'],off:['wa','Módulo de monitoramento sem sinal'],er:['er','Servidor sem resposta'],'':['','Módulo de monitoramento: verificando…']}[MODS];
  e.className='sb-i '+t[0];e.innerHTML='<i class="sb-dot" aria-hidden="true"></i>'+t[1];
  e.title=MODS==='ok'?'Último contato do ESP32: '+MODT:MODS==='off'?'O ESP32 não consultou o servidor nos últimos segundos. Os valores na tela podem estar desatualizados.':''}
async function modPoll(){if(document.hidden||MODB)return;MODB=true;
  try{const s=await api('GET','/api/status'),h=s&&s.hardware;MODS=h&&h.conectado?'ok':'off';MODT=h&&h.ultimoContato?new Date(h.ultimoContato).toLocaleTimeString('pt-BR'):''}
  catch(e){MODS='er'}finally{MODB=false;modRender()}}
/* Relógio do próprio navegador (sem consulta ao servidor) */
function clk(){const e=$('#sb-clk');if(!e)return;const d=new Date();
  e.innerHTML='<span class="sb-d">'+d.toLocaleDateString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit',year:'numeric'})+' · </span>'+d.toLocaleTimeString('pt-BR')}
function sbInit(){latRender();modRender();clk();
  if(!sbInit.t){sbInit.t=1;setInterval(clk,1000);setInterval(modPoll,10000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)modPoll()})}
  modPoll();const a=$('#sb-arq');if(a)a.onclick=()=>ajuda('sobre');const h=$('#hb');if(h)h.onclick=()=>ajuda('guia')}
/* Confirmação no padrão do sistema. Uso: if(await confirmar({titulo,texto,ok:'Remover painel',perigo:true})){...}
   O foco inicial fica em Cancelar; Esc também cancela.
   digitar:'QD-003' exige digitar o texto para habilitar o botão de confirmação (ações destrutivas). */
function confirmar({titulo,texto='',ok='Confirmar',cancelar='Cancelar',perigo=false,digitar=''}){
  return new Promise(res=>{let v=false;const d=document.createElement('dialog');d.className='cf';
    d.innerHTML=`<h1>${esc(titulo)}</h1><p>${esc(texto)}</p>${digitar?`<label for="cfd">Para confirmar, digite <b>${esc(digitar)}</b></label><input id="cfd" autocomplete="off" autocapitalize="characters" spellcheck="false">`:''}<div class="cfa"><button type="button" class="btn" data-n>${esc(cancelar)}</button><button type="button" class="btn ${perigo?'dg':'pr'}" data-s${digitar?' disabled':''}>${esc(ok)}</button></div>`;
    d.querySelector('[data-s]').onclick=()=>{v=true;d.close()};d.querySelector('[data-n]').onclick=()=>d.close();
    {const i=d.querySelector('#cfd'),s=d.querySelector('[data-s]'),nr=x=>String(x).replace(/\s+/g,'').toUpperCase();
     if(i){i.oninput=()=>{s.disabled=nr(i.value)!==nr(digitar)};i.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();if(!s.disabled)s.click()}}}}
    d.addEventListener('close',()=>{d.remove();res(v)});document.body.append(d);d.showModal();(d.querySelector('#cfd')||d.querySelector('[data-n]')).focus()})}
/* Botão em "Salvando…" enquanto a ação roda (evita envio duplo). ref = evento de submit/click ou o próprio botão.
   Uso: form.onsubmit=e=>{e.preventDefault();return guardar(e,async()=>{...})} */
async function guardar(ref,fn,txt='Salvando…'){
  const b=ref instanceof Event?(ref.submitter||(ref.target.matches&&ref.target.matches('button')?ref.target:ref.target.querySelector&&ref.target.querySelector('button:not([type=button])'))):ref;
  if(b&&b.disabled)return;const old=b?b.innerHTML:'';
  if(b){b.disabled=true;b.classList.add('busy');b.textContent=txt}
  try{return await fn()}finally{if(b){b.disabled=false;b.classList.remove('busy');b.innerHTML=old}}}
/* Estados vazios: explicam o que houve e o próximo passo */
const vazio=(t,d='')=>`<div class="vz"><b>${esc(t)}</b>${esc(d)}</div>`;
const vazioTr=(cols,t,d='')=>`<tr><td colspan="${cols}" class="vz"><b>${esc(t)}</b>${esc(d)}</td></tr>`;
const CH=[];
function chart(cv,data,o={}){const i=CH.findIndex(a=>a[0]===cv);if(i>=0)CH[i]=[cv,data,o];else CH.push([cv,data,o]);draw(cv,data,o)}
function draw(cv,data,o){const c=getComputedStyle(document.documentElement),x=cv.getContext('2d'),r=devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;if(!w)return;cv.width=w*r;cv.height=h*r;x.scale(r,r);
const mn=o.min??(data.length?Math.min(...data):0),mx=o.max??(data.length?Math.max(...data):1),p=30,X=i=>p+i*(w-p-6)/Math.max(data.length-1,1),Y=v=>h-14-(v-mn)/(mx-mn||1)*(h-26);
x.font='10px Segoe UI';x.lineWidth=1;
for(let i=0;i<=3;i++){const v=mn+(mx-mn)*i/3,y=Y(v);x.strokeStyle=c.getPropertyValue('--bd');x.beginPath();x.moveTo(p,y);x.lineTo(w,y);x.stroke();x.fillStyle=c.getPropertyValue('--mu');x.fillText(Math.round(v),0,y+3)}
if(o.lim&&o.lim>=mn&&o.lim<=mx){x.strokeStyle=c.getPropertyValue('--er');x.setLineDash([5,4]);x.beginPath();x.moveTo(p,Y(o.lim));x.lineTo(w,Y(o.lim));x.stroke();x.setLineDash([])}
if(data.length<2)return;
x.strokeStyle=c.getPropertyValue('--ac');x.lineWidth=1.8;x.beginPath();data.forEach((v,i)=>i?x.lineTo(X(i),Y(v)):x.moveTo(X(i),Y(v)));x.stroke()}
addEventListener('resize',()=>CH.forEach(a=>draw(...a)));
function setTheme(){const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;lsSet('simpe-theme',t);CH.forEach(a=>draw(...a));$$('[data-tg]').forEach(b=>b.textContent=t==='dark'?'Tema claro':'Tema escuro')}
function bindTheme(){$$('[data-tg]').forEach(b=>{b.textContent=document.documentElement.dataset.theme==='dark'?'Tema claro':'Tema escuro';b.onclick=setTheme})}
document.addEventListener('DOMContentLoaded',()=>{bindTheme();
document.addEventListener('click',e=>{const b=e.target.closest('[data-m]');$$('.menu').forEach(m=>{if(!b||m.id!==b.dataset.m)m.hidden=true});if(b){const m=$('#'+b.dataset.m);if(m)m.hidden=!m.hidden}
  $$('[data-m]').forEach(x=>{const m=$('#'+x.dataset.m);x.setAttribute('aria-expanded',String(!!m&&!m.hidden))})});
document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;const ab=$$('.menu').filter(m=>!m.hidden);if(!ab.length)return;
  ab.forEach(m=>{m.hidden=true;const b=$('[data-m="'+m.id+'"]');if(b){b.setAttribute('aria-expanded','false');b.focus()}})})});

/* Semáforo de saúde do painel. p = item de /api/paineis, L = resposta de /leituras (opcional).
   Retorna {k:'ok'|'wa'|'er'|'off', t:texto}. Mesmos critérios do servidor (severidade do alarme):
   Normal: tudo abaixo de 90% do limite · Atenção: de 90% até 110% do limite (alarme "Atenção" a partir de 100%)
   Crítico: acima de 110% do limite, fumaça ou porta aberta. Sem leituras para conferir, alarme ativo = Crítico (pior caso).
   PORTA_CRITICA=false volta a porta aberta para Atenção. */
const PORTA_CRITICA=false;
function saude(p,L){
  if(!p.online)return{k:'off',t:'Sem sinal'};
  const tem=!!(L&&L.valores);let k=p.alertas>0?(tem?'wa':'er'):'ok';
  if(tem){const v=L.valores,lim=L.limites||p.limites||{};
    ['corrente','temperatura','umidade','vibracao'].forEach(n=>{const x=v[n],l=lim[n];
      if(typeof x==='number'&&l>0){if(x>l*1.1)k='er';else if(x>=l*.9&&k!=='er')k='wa'}});
    if(v.fumaca)k='er';
    if(v.porta==='aberta'){if(PORTA_CRITICA)k='er';else if(k!=='er')k='wa'}}
  return{k,t:{ok:'Normal',wa:'Atenção',er:'Crítico'}[k]}}
/* Ordem de gravidade para a Central: Crítico > Atenção > Online (normal) > Offline. Uso: lista.sort((a,b)=>ordemSaude(ha)-ordemSaude(hb)) */
const ordemSaude=h=>({er:0,wa:1,ok:2,off:3})[h&&h.k]??4;
/* Legenda dos estados (mesmos critérios de saude()). Inserir onde houver semáforo: el.insertAdjacentHTML('beforeend',LEGENDA()) */
const LEGENDA=()=>`<details class="leg"><summary>Como ler os estados</summary><ul><li><b class="ok">Normal</b>Todas as medições abaixo de 90% do limite e nenhum alarme ativo.</li><li><b class="wa">Atenção</b>Alguma medição entre 90% e 110% do limite (a partir de 100% o sistema registra alarme) ou porta aberta.</li><li><b class="er">Crítico</b>Medição acima de 110% do limite ou fumaça detectada.</li><li><b class="mu2">Sem sinal</b>O módulo de monitoramento do painel não está comunicando; os valores podem estar desatualizados.</li><li><b class="mu2">Sem leitura</b>O servidor não entregou as leituras deste painel agora.</li></ul></details>`;
/* Botão Voltar (link real, destino explícito). Com crumb vira trilha: ← Central de Painéis › QD-001 · Nome.
   Uso: voltar('catalogo.html','Central de Painéis','QD-001 · Nome') */
const voltar=(href,txt,crumb='')=>`<nav class="trail" aria-label="Navegação"><a class="btn sm back" href="${esc(href)}"><span aria-hidden="true">←</span> ${esc(txt)}</a>${crumb?`<span class="crumb"><span aria-hidden="true">›</span> ${esc(crumb)}</span>`:''}</nav>`;
/* Abas ↔ hash da URL (sobrevive ao F5 e ao botão Voltar do navegador).
   mapa = {slug:chave}; aplicar(chave) mostra a aba SEM gravar de novo; H.gravar(chave) acrescenta ao histórico.
   Uso: const H=abaHash({alarmes:'alm',sensores:'sens'},'dash',k=>mostrar(k)); mostrar(H.ler()); ao clicar: mostrar(k);H.gravar(k) */
function abaHash(mapa,padrao,aplicar){
  const inv=Object.fromEntries(Object.entries(mapa).map(([s,k])=>[k,s]));
  const ler=()=>{let h='';try{h=decodeURIComponent(location.hash.slice(1))}catch(e){}return Object.prototype.hasOwnProperty.call(mapa,h)?mapa[h]:padrao};
  const volta=()=>aplicar(ler());addEventListener('popstate',volta);addEventListener('hashchange',volta);
  return{ler,gravar:k=>{const s=inv[k];if(s&&location.hash.slice(1)!==s)history.pushState(null,'','#'+s)}}}

let ME=null;
const LOGO_I='<img class="lgd" src="img/logo-simpe-icone.png" alt=""><img class="lgl" src="img/logo-simpe-icone-escuro.png" alt="">';
/* Tela de falha com "Tentar novamente" (C2). Esconde o conteúdo vazio da página e mostra o motivo. */
function falha(msg){$$('body>main,body>.shell').forEach(x=>x.hidden=true);if($('#fb'))return;
  document.body.insertAdjacentHTML('beforeend',`<main class="fb" id="fb" role="alert"><h1>Não foi possível carregar o SIMPE</h1><p class="mu">${esc(msg||'Falha ao falar com o servidor.')}</p><button class="btn pr" id="fbr" type="button">Tentar novamente</button> <a class="btn" href="login.html">Ir para o login</a></main>`);
  $('#fbr').onclick=()=>location.reload()}
const ICO={
  bell:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>',
  user:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>',
  find:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 5 5"/></svg>'};
const TBCSS=`.top .tt{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:15px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;white-space:nowrap;pointer-events:none}
.ic{width:36px;height:36px;display:grid;place-items:center;padding:0}
.ic svg,.search button svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.ic .bd{position:absolute;top:-3px;right:-3px;margin:0;min-width:16px;text-align:center;line-height:16px;font-size:12px;padding:0 4px}
.search button{background:none;border:0;color:var(--tx);cursor:pointer;display:grid;place-items:center;padding:4px;flex:none}
.top .search{margin-right:8px}
.qm{font-weight:700;font-size:15px;line-height:1;width:22px;height:22px;display:grid;place-items:center;border:1.8px solid currentColor;border-radius:50%}
.menu .who{cursor:default}
@media(max-width:1100px){.top .tt{display:none}}
@media(max-width:800px){.top .search{width:150px}}`;
/* Barra superior com usuário real. Uso: topbar('cat').then(me=>{...})
   Páginas com busca própria definem window.onTopSearch=fn; nas demais, a busca leva ao catálogo. */
/* Notificações: alarmes ativos vêm de /api/alarmes (painel + sensor) e abrem direto painel.html?id=QD-XXX#alarmes.
   O resto (solicitações etc.) continua em /api/notificacoes; o item genérico "N alarmes ativos" é descartado quando /api/alarmes responde. */
const ALM_SENS={corrente:'Corrente',temperatura:'Temperatura',umidade:'Umidade',vibracao:'Vibração',fumaca:'Fumaça'};
const almNome=s=>ALM_SENS[s]||String(s||'Sensor');
const almQuando=a=>{const c=a&&a.criadoEm;return c&&c.data?br(c.data).slice(0,5)+' '+String(c.hora||'').slice(0,5):''};
const tempoRel=c=>{const t=c&&(c.ts||c);const m=Math.round((Date.now()-new Date(t).getTime())/60000);return isNaN(m)?'':m<1?'agora há pouco':m<60?'há '+m+' min':m<1440?'há '+Math.floor(m/60)+' h':'há '+Math.floor(m/1440)+' d'};
const ordemSev=a=>a.severidade==='Crítico'?0:1;
/* Alarmes ativos (mais graves primeiro; dentro da gravidade, os mais recentes) — reaproveitável pela Central */
async function alarmesAtivos(){const l=await api('GET','/api/alarmes');return(Array.isArray(l)?l:[]).filter(a=>a.estado==='Ativo').map((a,i)=>[a,i]).sort((x,y)=>ordemSev(x[0])-ordemSev(y[0])||x[1]-y[1]).map(x=>x[0])}
const almItem=a=>({id:a.id,sev:a.severidade||'Atenção',titulo:a.painelId+' · '+almNome(a.sensor),texto:a.mensagem,quando:almQuando(a),link:'painel.html?id='+encodeURIComponent(a.painelId)+'#alarmes'});
async function ntCarregar(){
  const [al,gn]=await Promise.all([alarmesAtivos().catch(()=>null),api('GET','/api/notificacoes').catch(()=>null)]);
  if(!al&&!Array.isArray(gn))return null;
  const outros=(Array.isArray(gn)?gn:[]).filter(n=>!(al&&/alarmes? ativos?/i.test(n.titulo)));
  return[...(al||[]).map(almItem),...outros]}
const ntLink=n=>{if(n.link)return n.link;const id=typeof n.painelId==='string'?n.painelId:typeof n.painel==='string'?n.painel:((n.titulo+' '+n.texto).match(/QD-\d{3}/i)||[])[0];return id?'painel.html?id='+encodeURIComponent(id.toUpperCase())+'#alarmes':''};
const ntHtml=nt=>{if(!nt.length)return'<div class="mu sm">Nenhuma notificação.</div>';let c=0,mais=0;const it=[];
  nt.forEach(n=>{if(n.sev&&++c>6){mais++;return}it.push(n)});
  return it.map(n=>{const l=ntLink(n);return `<${l?`a href="${esc(l)}"`:'div'}>${n.sev?`<span class="pill ${n.sev==='Crítico'?'er':'wa'} sm">${esc(n.sev)}</span> `:''}<b>${esc(n.titulo)}</b><br><span class="mu sm">${esc(n.texto)}${n.quando?' · '+esc(n.quando):''}</span></${l?'a':'div'}>`}).join('')
    +(mais?`<a href="catalogo.html"><b>+ ${mais} alarme${mais>1?'s':''} ativo${mais>1?'s':''}</b><br><span class="mu sm">Ver todos na Central de Painéis</span></a>`:'')};
function ntRender(nt){const m=$('#mn'),b=$('#nbd'),t=$('#nbt');if(!m||!b)return;m.innerHTML=ntHtml(nt);b.hidden=!nt.length;b.textContent=nt.length;if(t)t.setAttribute('aria-label','Notificações'+(nt.length?' ('+nt.length+')':''))}
async function topbar(on,title){
  let me,nt;
  try{[me,nt]=await Promise.all([api('GET','/api/me'),ntCarregar().then(x=>x||[])])}
  catch(e){if(e.message!=='Sessão expirada')falha(e.message);return new Promise(()=>{})}
  ME=me;
  const adm=me.perfil==='Administrador';
  if(!$('#tbcss'))document.head.insertAdjacentHTML('beforeend',`<style id="tbcss">${TBCSS}</style>`);
  document.body.insertAdjacentHTML('afterbegin',`<header class="top"><a class="logo" href="catalogo.html" aria-label="SIMPE · Central de Painéis">${LOGO_I}<span>SIMPE</span></a>
<nav><a class="nl ${on=='cat'?'on':''}" href="catalogo.html">Central de Painéis</a>${adm?`<a class="nl ${on=='adm'?'on':''}" href="admin.html">Administração</a>`:''}</nav>
<span class="tt">${esc(title||(on=='adm'?'Administração':'Central de Painéis'))}</span>
${window.onTopSearch?`<form class="search" id="tf" role="search"><input id="tq" type="text" placeholder="Buscar painéis..." aria-label="Buscar painéis" autocomplete="off"><button aria-label="Buscar">${ICO.find}</button></form>`:''}
<button class="ib ic" id="hb" type="button" aria-label="Ajuda (atalho: ?)" title="Ajuda (atalho: ?)"><span class="qm" aria-hidden="true">?</span></button>
<div class="wrap"><button class="ib ic" id="nbt" data-m="mn" aria-label="Notificações${nt.length?' ('+nt.length+')':''}" title="Notificações">${ICO.bell}<span class="bd" id="nbd"${nt.length?'':' hidden'}>${nt.length}</span></button><div class="menu" id="mn" hidden>${ntHtml(nt)}</div></div>
<div class="wrap"><button class="ib ic" data-m="mu" aria-label="Menu do usuário" title="${esc(me.nome)}">${ICO.user}</button><div class="menu" id="mu" hidden><div class="who"><b>${esc(me.nome)}</b><br><span class="mu sm">${esc(me.departamento)} · ${esc(me.perfil)}</span></div><a class="mob" href="catalogo.html">Central de Painéis</a>${adm?'<a class="mob" href="admin.html">Administração</a>':''}<button id="bp">Minha conta</button><button id="bs">Alterar senha</button><button data-tg></button><button id="bx">Sair</button></div></div></header>
<dialog id="dp"><form id="fp"><h1>Minha conta</h1><p class="mu sm">${esc(me.email)} · ID ${esc(me.idFuncionario)}</p><label for="pn">Nome</label><input id="pn" required value="${esc(me.nome)}"><label for="pd">Departamento</label><input id="pd" required value="${esc(me.departamento)}"><p class="msg" id="pg"></p><div class="row" style="justify-content:flex-end;margin-top:14px"><button type="button" class="btn" data-x="dp">Cancelar</button><button class="btn pr">Salvar</button></div></form></dialog>
<dialog id="ds"><form id="fs2"><h1>Alterar senha</h1><label for="sa">Senha atual</label><input id="sa" type="password" required><label for="sn">Nova senha</label><input id="sn" type="password" required minlength="8"><label for="sc">Confirmar nova senha</label><input id="sc" type="password" required><p class="msg" id="sg"></p><div class="row" style="justify-content:flex-end;margin-top:14px"><button type="button" class="btn" data-x="ds">Cancelar</button><button class="btn pr">Salvar</button></div></form></dialog>`);
  bindTheme();
  if(!$('#lat'))document.body.insertAdjacentHTML('beforeend','<footer id="lat" class="sbar" aria-label="Barra de status"><span id="sb-mod" class="sb-i" role="status"></span><span id="sb-lat" class="sb-i"></span><span class="sb-r"><span id="sb-clk" class="sb-i" title="Relógio deste computador" aria-hidden="true"></span><button type="button" class="lk" id="sb-arq" title="Como o SIMPE guarda os dados e onde roda">Arquitetura</button></span></footer><div id="prh" aria-hidden="true"></div>');sbInit();
  if($('#tq')){$('#tq').oninput=()=>window.onTopSearch();$('#tf').onsubmit=e=>{e.preventDefault();window.onTopSearch()}}
  const msg=(id,t,ok)=>{const g=$('#'+id);g.className='msg '+(ok?'ok':'er');g.textContent=t};
  $$('[data-x]').forEach(b=>b.onclick=()=>$('#'+b.dataset.x).close());
  $('#bp').onclick=()=>{$('#pg').textContent='';$('#dp').showModal()};
  $('#bs').onclick=()=>{$('#fs2').reset();$('#sg').textContent='';$('#ds').showModal()};
  $('#bx').onclick=async()=>{try{await api('POST','/api/logout')}catch(e){}lsSet('simpe-sess','');location.href='login.html'};
  $('#fp').onsubmit=e=>{e.preventDefault();const en=val.nome($('#pn').value),ed=val.texto($('#pd').value,2,'Departamento');if(en||ed)return msg('pg',en||ed);const nm=limpa($('#pn').value),dp=limpa($('#pd').value);return guardar(e,async()=>{try{await api('PUT','/api/me',{nome:nm,departamento:dp});location.reload()}catch(x){msg('pg',x.message)}})};
  $('#fs2').onsubmit=e=>{e.preventDefault();if($('#sn').value===$('#sa').value)return msg('sg','A nova senha deve ser diferente da senha atual.');if($('#sn').value!==$('#sc').value)return msg('sg','As senhas não coincidem.');
    return guardar(e,async()=>{try{await api('POST','/api/senha',{atual:$('#sa').value,nova:$('#sn').value});$('#ds').close();toast('Senha alterada','ok')}catch(x){msg('sg',x.message)}})};
  /* Sino: renovado a cada 10 s (pausa com a aba oculta). Itens novos viram toast, exceto no painel, que já avisa por som e banner. */
  const kn=n=>n.id||[n.titulo,n.texto,ntLink(n)].join('|');let nk=new Set(nt.map(kn)),nb=false;
  const nr=async()=>{if(nb||document.hidden)return;nb=true;
    try{const x=await ntCarregar();if(!x)return;
      const novos=x.filter(n=>!nk.has(kn(n)));nk=new Set(x.map(kn));ntRender(x);
      if(novos.length&&!/painel\.html/.test(location.pathname))toast((novos[0].sev?'Novo alarme: ':'Nova notificação: ')+novos[0].titulo+(novos.length>1?' (+'+(novos.length-1)+')':''),novos[0].sev==='Crítico'?'er':'')}
    catch(e){}finally{nb=false}};
  setInterval(nr,10000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)nr()});
  return me}


/* ===== Validação e sanitização de formulários ===== */
const limpa=s=>String(s==null?'':s).replace(/\s+/g,' ').trim();           /* texto: trim + espaços colapsados */
const emailN=s=>String(s==null?'':s).replace(/\s+/g,'').toLowerCase();    /* e-mail: sem espaços, minúsculo */
const idN=s=>String(s==null?'':s).replace(/\s+/g,'');                      /* códigos/IDs: sem espaços */
const RE={email:/^[^\s@]{1,64}@[^\s@.]+(\.[^\s@.]+)+$/,id:/^[A-Za-z0-9._\/-]{2,40}$/};
const val={
  nome:s=>{s=limpa(s);return s.length<3?'Informe o nome completo (mínimo de 3 caracteres).':!/\p{L}/u.test(s)?'O nome deve conter letras.':''},
  email:s=>{s=emailN(s);return !s?'Informe o e-mail corporativo.':!RE.email.test(s)?'E-mail inválido. Exemplo: nome@empresa.com.br':''},
  id:s=>{s=idN(s);return !s?'Informe o ID do funcionário.':!RE.id.test(s)?'Use de 2 a 40 caracteres: letras, números, ponto, hífen, barra ou sublinhado.':''},
  texto:(s,min=3,nome='Campo')=>limpa(s).length<min?nome+': informe pelo menos '+min+' caracteres.':''};
const ancora=i=>i.parentNode&&i.parentNode.classList.contains('pw')?i.parentNode:i;
/* Mensagem de erro ligada ao campo (aria-invalid/aria-describedby). msg='' limpa. Retorna true se válido. */
function erroCampo(i,msg){let e=document.getElementById(i.id+'-e');
  if(!e){if(!msg)return true;e=document.createElement('small');e.id=i.id+'-e';e.className='fe';ancora(i).insertAdjacentElement('afterend',e)}
  e.textContent=msg||'';e.hidden=!msg;
  if(msg){i.setAttribute('aria-invalid','true');i.setAttribute('aria-describedby',e.id)}else{i.removeAttribute('aria-invalid');i.removeAttribute('aria-describedby')}
  return !msg}
/* Botão mostrar/ocultar senha + aviso de Caps Lock */
function olho(i){const w=document.createElement('div');w.className='pw';i.parentNode.insertBefore(w,i);w.append(i);
  const b=document.createElement('button');b.type='button';b.className='pwb';b.textContent='Mostrar';b.setAttribute('aria-label','Mostrar senha');b.setAttribute('aria-pressed','false');
  b.onclick=()=>{const v=i.type==='password';i.type=v?'text':'password';b.textContent=v?'Ocultar':'Mostrar';b.setAttribute('aria-pressed',String(v));b.setAttribute('aria-label',v?'Ocultar senha':'Mostrar senha')};w.append(b);
  const k=document.createElement('small');k.className='fe wa';k.id=i.id+'-c';k.hidden=true;k.textContent='Caps Lock ativado.';w.insertAdjacentElement('afterend',k);
  const cap=ev=>{if(ev.getModifierState)k.hidden=!ev.getModifierState('CapsLock')};
  i.addEventListener('keydown',cap);i.addEventListener('keyup',cap);i.addEventListener('blur',()=>{k.hidden=true})}


/* ===== Central de Ajuda (botão ? e tecla ?) ===== */
const AJ_GUIA=`<h2>Como ler a tela</h2>
<p class="mu">Cada painel mostra um estado. As cores e palavras são as mesmas em todo o sistema:</p>
<ul class="hl"><li><b class="ok">Normal</b><span>Tudo abaixo de 90% do limite configurado e nenhum alarme ativo. Não precisa fazer nada.</span></li>
<li><b class="wa">Atenção</b><span>Alguma medição está entre 90% e 110% do limite (a partir de 100% o sistema registra um alarme) ou porta aberta. Acompanhe e verifique o painel.</span></li>
<li><b class="er">Crítico</b><span>Medição acima de 110% do limite ou fumaça detectada. Atue logo.</span></li>
<li><b class="mu2">Sem sinal</b><span>O módulo de monitoramento do painel não está enviando dados. Os números na tela podem estar desatualizados.</span></li></ul>
<h2>Apareceu um alerta. E agora?</h2>
<ol class="hl n"><li>Clique no sino ou no aviso para abrir o painel com problema.</li><li>Veja qual medição passou do limite (temperatura, corrente, fumaça…).</li><li>Confira o painel com segurança e siga o procedimento da sua empresa.</li><li>Quando alguém já estiver cuidando, marque “Estou ciente”.</li></ol>
<p class="mu sm">O SIMPE avisa e registra; ele não desliga máquinas. O único comando pelo site é ligar ou desligar as 2 ventoinhas. O aviso sonoro da tela vem do navegador: deixe a aba aberta e o som ligado.</p>
<h2>Sensores e equipamentos deste protótipo</h2>
<div class="tw"><table class="ht"><thead><tr><th>Componente</th><th>O que faz</th><th>Bom saber</th></tr></thead><tbody>
<tr><td><b>DS18B20</b></td><td>Temperatura dentro do painel</td><td>Sensor digital estável. Mede só o ponto onde está instalado.</td></tr>
<tr><td><b>DHT22</b></td><td>Temperatura e umidade do ar</td><td>Atualiza devagar (cerca de uma leitura a cada 2 s). A umidade tem margem de erro de alguns pontos percentuais.</td></tr>
<tr><td><b>ACS712 5A</b></td><td>Corrente elétrica (A)</td><td>No protótipo mede até 5 A. Os limites de até 25 A cadastrados nos painéis valem para o produto final, com sensor adequado.</td></tr>
<tr><td><b>MQ-2</b></td><td>Fumaça e gases combustíveis</td><td>Indica presença de fumaça; não informa a quantidade nem o tipo de gás. Precisa de alguns minutos de aquecimento ao ligar.</td></tr>
<tr><td><b>SW-420</b></td><td>Vibração</td><td>Sensor simples de trepidação e batidas. Serve de alerta; não substitui análise profissional de vibração.</td></tr>
<tr><td><b>Micro Switch</b></td><td>Porta do painel aberta ou fechada</td><td>Aviso imediato quando a porta é aberta.</td></tr>
<tr><td><b>Cooler 12V</b> (2)</td><td>Ventilação do painel</td><td>Único equipamento comandado pelo site (perfil com permissão de controle).</td></tr>
<tr><td><b>Relé e buzzer</b></td><td>Ação e aviso locais no ESP32</td><td>Funcionam no próprio painel; o site não liga nem desliga.</td></tr>
<tr><td><b>ESP32-CAM</b></td><td>Câmera</td><td>Não disponível nesta versão.</td></tr></tbody></table></div>`;
const AJ_SOBRE=`<div class="row" style="justify-content:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:12px"><span class="mu sm">Nível de detalhe:</span><div class="seg" role="group" aria-label="Nível de detalhe"><button type="button" data-hv="s" aria-pressed="true">Visão simples</button><button type="button" data-hv="t" aria-pressed="false">Visão técnica</button></div></div>
<h2>O caminho de uma medição</h2>
<div class="fl">
<div class="fn"><b>Painel</b><p class="vs">Sensores medem temperatura, corrente, umidade, vibração, fumaça e porta.</p><p class="vt">DS18B20, DHT22, ACS712 5A, MQ-2, SW-420 e micro switch ligados ao ESP32.</p></div>
<div class="fa"><span class="ar" aria-hidden="true">→</span><span>1 · mede</span></div>
<div class="fn"><b>ESP32</b><p class="vs">Mini-computador dentro do painel. Envia as medidas pela rede e liga/desliga as ventoinhas.</p><p class="vt">Wi-Fi + HTTP/JSON. Consulta GET /api/estado a cada 0,5 s (ventoinhas); o servidor aceita leituras em POST /api/leituras com token de dispositivo.</p></div>
<div class="fa"><span class="ar" aria-hidden="true">→</span><span>2 · envia</span></div>
<div class="fn"><b>Servidor</b><p class="vs">Recebe os dados, compara com os limites e gera os alarmes.</p><p class="vt">Node.js/Express. Alarme “Atenção” acima de 100% do limite e “Crítico” acima de 110%. Sessão HttpOnly de 12 h; senhas com scrypt.</p></div>
<div class="fa"><span class="ar" aria-hidden="true">→</span><span>3 · grava</span></div>
<div class="fn"><b>Banco</b><p class="vs">Guarda os dados, o histórico e quem fez o quê.</p><p class="vt">MVP: 9 arquivos .json com gravação atômica; 120 leituras por painel em memória; até 10.000 eventos de histórico.</p></div>
<div class="fa"><span class="ar" aria-hidden="true">→</span><span>4 · mostra</span></div>
<div class="fn"><b>Navegador</b><p class="vs">Você acompanha tudo de qualquer computador ou tablet da rede.</p><p class="vt">HTML/JS puro consultando a API periodicamente; timeout de 8 s e medição de latência a cada requisição.</p></div>
</div>
<h2>Hoje e em produção</h2>
<div class="cmp"><div class="card"><span class="pill wa sm">Hoje (MVP)</span><h3>JSON atômico</h3>
<p class="vs">Dados em arquivos simples no próprio servidor. Ótimo para demonstrar e testar; não é pensado para muitos painéis nem para anos de histórico.</p>
<p class="vt">Node.js/Express + 9 arquivos .json (escrita atômica). 120 leituras por painel em memória, 10.000 eventos de histórico, sessão de 12 h, senhas com scrypt.</p></div>
<div class="cmp-a" aria-hidden="true">→</div>
<div class="card"><span class="pill ok sm">Em produção (fábrica)</span><h3>PostgreSQL + TimescaleDB</h3>
<p class="vs">Banco profissional: guarda anos de histórico, controla quem acessa o quê e registra tudo para auditoria. As medições ficam em um banco próprio para dados ao longo do tempo.</p>
<p class="vt">PostgreSQL (usuários, permissões, painéis, auditoria) + TimescaleDB ou InfluxDB (séries temporais de sensores), com retenção e agregação de dados.</p></div></div>
<h2>Nuvem ou local? Recomendado: híbrido</h2>
<div class="tw"><table class="ht"><thead><tr><th></th><th>Só nuvem</th><th>Só local (on-premises)</th><th>Híbrido <span class="pill ok sm">recomendado</span></th></tr></thead><tbody>
<tr><td><b>Sem internet</b></td><td>Para de monitorar</td><td>Continua funcionando</td><td>Continua funcionando no mini-servidor da fábrica</td></tr>
<tr><td><b>Acesso de fora</b></td><td>De qualquer lugar</td><td>Só na rede da fábrica (ou VPN)</td><td>Gestores acessam uma cópia na nuvem (opcional)</td></tr>
<tr><td><b>Rapidez dos alertas</b></td><td>Depende da internet</td><td>Rede local, resposta rápida</td><td>Alertas locais, sem depender da internet</td></tr>
<tr><td><b>Custo e manutenção</b></td><td>Mensalidade, sem servidor próprio</td><td>Servidor e equipe de TI na fábrica</td><td>Mini-servidor local + nuvem apenas se a empresa quiser</td></tr>
<tr><td><b>Dados</b></td><td>Ficam fora da fábrica</td><td>Ficam dentro da fábrica</td><td>Ficam na fábrica; só vai à nuvem o que for autorizado</td></tr>
<tr class="vt"><td><b>Sincronização</b></td><td>—</td><td>—</td><td>Fila local (store-and-forward) enquanto estiver offline; replicação assíncrona para a nuvem</td></tr></tbody></table></div>
<h2>Rede e latência</h2>
<p class="vs mu">O rodapé mostra quanto tempo o servidor leva para responder ao seu navegador. Se aparecer “sem resposta”, verifique a rede da fábrica.</p>
<p class="vt mu">Latência = tempo entre enviar a requisição e receber a resposta, medido no navegador em cada chamada à API (última e média das 10 últimas). Sem resposta em 8 s, a requisição é cancelada e a faixa de “sem conexão” aparece.</p>`;
const AJ_HTML=()=>`<dialog id="dh" class="help" data-v="${lsGet('simpe-help-vis')==='t'?'t':'s'}" aria-labelledby="dht"><div class="hh"><h1 id="dht">Central de Ajuda</h1><button type="button" class="btn sm" data-hx>Fechar</button></div>
<div class="tabs" role="tablist" aria-label="Ajuda"><button type="button" role="tab" data-ht="guia" class="on" aria-selected="true">Guia rápido e sensores</button><button type="button" role="tab" data-ht="sobre" aria-selected="false">Sobre o sistema (banco e hospedagem)</button></div>
<div class="hb"><section data-hs="guia" role="tabpanel">${AJ_GUIA}</section><section data-hs="sobre" role="tabpanel" hidden>${AJ_SOBRE}</section></div></dialog>`;
function ajudaAba(k){const d=$('#dh');if(!d)return;
  $$('[data-ht]',d).forEach(b=>{const on=b.dataset.ht===k;b.classList.toggle('on',on);b.setAttribute('aria-selected',String(on))});
  $$('[data-hs]',d).forEach(x=>x.hidden=x.dataset.hs!==k);$('.hb',d).scrollTop=0}
function ajudaVis(v){const d=$('#dh');if(!d)return;d.dataset.v=v;$$('[data-hv]',d).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.hv===v)));lsSet('simpe-help-vis',v)}
/* ajuda('guia') abre o Guia Rápido & Sensores · ajuda('sobre') abre Sobre o Sistema */
function ajuda(aba='guia'){let d=$('#dh');
  if(!d){document.body.insertAdjacentHTML('beforeend',AJ_HTML());d=$('#dh');
    d.onclick=e=>{if(e.target===d)d.close();const t=e.target.closest('[data-ht]'),v=e.target.closest('[data-hv]');if(t)ajudaAba(t.dataset.ht);if(v)ajudaVis(v.dataset.hv);if(e.target.closest('[data-hx]'))d.close()};
    ajudaVis(d.dataset.v)}
  ajudaAba(aba);if(!d.open)d.showModal()}
addEventListener('keydown',e=>{if(e.key!=='?'||e.ctrlKey||e.metaKey||e.altKey)return;
  const t=e.target,tag=t&&t.tagName;if(/^(INPUT|TEXTAREA|SELECT)$/.test(tag)||(t&&t.isContentEditable))return;
  const d=$('#dh');if(d&&d.open){d.close();return}
  if($$('dialog[open]').length||!$('#hb'))return;e.preventDefault();ajuda('guia')});

/* ===== Impressão / relatório PDF =====
   imprimir('Título do relatório','subtítulo opcional') → window.print() (no diálogo, escolha "Salvar como PDF").
   Ctrl+P também funciona: o cabeçalho técnico (#prh) e o tema claro são aplicados em beforeprint/afterprint. */
let PRT=null,PRTH=null;
function imprimir(titulo,sub){PRT={titulo,sub};try{window.print()}finally{PRT=null}}
function prFill(){const e=$('#prh');if(!e)return;const t=(PRT&&PRT.titulo)||document.title.replace(/\s*·\s*SIMPE\s*$/,'')||'Relatório',n=new Date(),q=new URLSearchParams(location.search).get('id');
  e.innerHTML=`<img src="img/logo-simpe-escuro.png" alt="" onerror="this.remove()"><div class="prt"><b>SIMPE · Sistema Integrado de Monitoramento de Painéis Elétricos</b><span>${esc(t)}${q?' · '+esc(q):''}</span>${PRT&&PRT.sub?`<span>${esc(PRT.sub)}</span>`:''}</div><dl><dt>Emitido em</dt><dd>${esc(n.toLocaleString('pt-BR'))}</dd><dt>Emitido por</dt><dd>${esc(ME?ME.nome+' · '+ME.perfil:'—')}</dd></dl>`}
addEventListener('beforeprint',()=>{prFill();const d=document.documentElement;PRTH=d.dataset.theme;if(PRTH!=='light'){d.dataset.theme='light';CH.forEach(a=>draw(...a))}});
addEventListener('afterprint',()=>{if(PRTH){document.documentElement.dataset.theme=PRTH;PRTH=null;CH.forEach(a=>draw(...a))}});
